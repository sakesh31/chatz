import React, { useState } from 'react';
import brandingLogo from './assets/branding-logo.png';

function Login({ onSwitchToSignup, onLogin, error }) {
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  return (
    <div style={{ minHeight: '100vh', background: '#181818', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{
        background: '#232323',
        color: '#ececec',
        borderRadius: 18,
        boxShadow: '0 4px 32px rgba(0,0,0,0.28)',
        border: '1.5px solid #232323',
        padding: '48px 40px 36px 40px',
        minWidth: 380,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        fontFamily: 'Montserrat, Segoe UI, Roboto, Arial, sans-serif',
      }}>
        <h2 style={{ fontSize: '2.5rem', marginBottom: 18, fontFamily: 'Montserrat, Segoe UI, Roboto, Arial, sans-serif', letterSpacing: 1, fontWeight: 700 }}>Login to chatz</h2>
        <img src={brandingLogo} alt="logo" style={{ width: 120, height: 120, borderRadius: '50%', objectFit: 'cover', marginBottom: 24, boxShadow: '0 2px 12px rgba(0,0,0,0.18)', border: '3px solid #232323', background: '#181818' }} />
        <input type="text" placeholder="Username or Email" value={identifier} onChange={e => setIdentifier(e.target.value)} style={{ fontSize: '1.3rem', margin: '12px 0', padding: 16, borderRadius: 8, border: '1.5px solid #363a43', background: '#181818', color: '#ececec', width: 300, boxSizing: 'border-box', outline: 'none' }} />
        <div style={{ position: 'relative', width: 300, margin: '12px 0' }}>
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            style={{
              fontSize: '1.3rem',
              padding: '16px',
              borderRadius: 8,
              border: '1.5px solid #363a43',
              background: '#181818',
              color: '#ececec',
              width: '100%',
              boxSizing: 'border-box',
              paddingRight: 60
            }}
          />
          <button
            type="button"
            onClick={() => setShowPassword(v => !v)}
            style={{
              position: 'absolute',
              right: 18,
              top: '50%',
              transform: 'translateY(-50%)',
              background: 'none',
              border: 'none',
              color: '#ececec',
              fontSize: '1.1rem',
              cursor: 'pointer',
              padding: 0,
              height: 32
            }}
            tabIndex={-1}
          >
            {showPassword ? 'Hide' : 'Show'}
          </button>
        </div>
        <button style={{ fontSize: '1.2rem', margin: '18px 0 10px 0', padding: '14px 32px', borderRadius: 8, background: '#363a43', color: '#ececec', border: 'none', width: 300, fontWeight: 600, letterSpacing: 1, boxShadow: '0 2px 8px rgba(0,0,0,0.10)' }} onClick={() => onLogin(identifier, password)}>Login</button>
        <button style={{ fontSize: '1.2rem', margin: '0 0 8px 0', padding: '14px 32px', borderRadius: 8, background: 'none', color: '#ececec', border: '1.5px solid #363a43', width: 300, fontWeight: 600, letterSpacing: 1 }} onClick={onSwitchToSignup}>Switch to Signup</button>
        {error && <div style={{ color: 'red', marginTop: 18, fontSize: '1.1rem' }}>{error}</div>}
      </div>
    </div>
  );
}

export default Login; 