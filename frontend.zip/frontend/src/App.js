import React, { useState, useRef, useEffect, useCallback } from 'react';
import axios from 'axios';
import './App.css';
import Login from './Login';
import Signup from './Signup';
import brandingLogo from './assets/branding-logo.png';

const API_BASE = 'http://localhost:8000';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [conversations, setConversations] = useState([]);
  const [selectedConv, setSelectedConv] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [menuOpen, setMenuOpen] = useState(null); // conversation id or null
  const [modal, setModal] = useState(null); // {type, convId}
  const [modalValue, setModalValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const menuRef = useRef();
  const [ttsEnabled, setTtsEnabled] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [recognizing, setRecognizing] = useState(false);
  const [ttsPlayingId, setTtsPlayingId] = useState(null);
  const ttsUtteranceRef = useRef(null);
  const [pendingReply, setPendingReply] = useState(false);
  const [passwordPrompt, setPasswordPrompt] = useState(null);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [removePwModal, setRemovePwModal] = useState(null); // {convId}
  const [removePwInput, setRemovePwInput] = useState('');
  const [removePwError, setRemovePwError] = useState('');
  const [accountModal, setAccountModal] = useState(false);
  const [authPage, setAuthPage] = useState(() => {
    return localStorage.getItem('chatz_logged_in') === 'true' ? 'app' : 'login';
  });
  const [loginError, setLoginError] = useState("");
  const [signupError, setSignupError] = useState("");

  // Fetch conversations on mount
  useEffect(() => {
    fetchConversations();
  }, []);

  // Fetch messages when selectedConv changes
  useEffect(() => {
    if (selectedConv) {
      setError("");
      fetchMessages(selectedConv);
    } else {
      setMessages([]);
    }
  }, [selectedConv]);

  // Close menu on click outside
  useEffect(() => {
    function handleClick(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) {
        setMenuOpen(null);
      }
    }
    if (menuOpen) document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [menuOpen]);

  // When selectedConv changes, always prompt for password if set
  useEffect(() => {
    if (!selectedConv) return;
    const conv = conversations.find(c => c.id === selectedConv);
    if (conv && conv.password) {
      setPasswordPrompt({ convId: selectedConv });
    } else {
      setPasswordPrompt(null);
    }
  }, [selectedConv, conversations]);

  // TTS: Speak assistant message
  const speak = useCallback((text) => {
    if (!ttsEnabled || !window.speechSynthesis) return;
    const utter = new window.SpeechSynthesisUtterance(text);
    setSpeaking(true);
    utter.onend = () => setSpeaking(false);
    window.speechSynthesis.speak(utter);
  }, [ttsEnabled]);

  // Speak last assistant message when TTS is enabled
  useEffect(() => {
    if (!ttsEnabled) return;
    if (messages.length > 0) {
      const last = messages[messages.length - 1];
      if (last.role === 'assistant') speak(last.content);
    }
  }, [messages, ttsEnabled, speak]);

  // Speech-to-text (mic)
  const handleMic = () => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      alert('Speech recognition not supported in this browser. Try Chrome or Edge.');
      console.log('SpeechRecognition not supported');
      return;
    }
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    let didSend = false;
    setRecognizing(true);
    console.log('Mic: recognition.start()');
    let timeoutId = setTimeout(() => {
      recognition.stop();
      console.log('Mic: recognition stopped by timeout');
    }, 8000); // fallback: stop after 8 seconds if no speech
    recognition.onstart = () => {
      console.log('Mic: recognition started');
    };
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript.trim();
      setInput('');
      if (transcript && selectedConv) {
        setMessages((prev) => [...prev, { role: 'user', content: transcript }]);
        setPendingReply(true);
        const fd = new FormData();
        fd.append('role', 'user');
        fd.append('content', transcript);
        axios.post(`${API_BASE}/conversations/${selectedConv}/messages`, fd)
          .then(res => setMessages(res.data.history || []))
          .catch(() => setError('Failed to send message'))
          .finally(() => setPendingReply(false));
        didSend = true;
      }
      console.log('Mic: recognition result', transcript);
    };
    recognition.onspeechend = () => {
      clearTimeout(timeoutId);
      recognition.stop();
      console.log('Mic: onspeechend');
    };
    recognition.onerror = (e) => {
      clearTimeout(timeoutId);
      setRecognizing(false);
      console.log('Mic: recognition error', e);
    };
    recognition.onend = () => {
      clearTimeout(timeoutId);
      setRecognizing(false);
      console.log('Mic: recognition ended');
    };
    recognition.start();
  };

  // API: Fetch all conversations
  async function fetchConversations() {
    setLoading(true);
    try {
      const res = await axios.get(`${API_BASE}/conversations`);
      setConversations(res.data);
      if (!selectedConv && res.data.length > 0) setSelectedConv(res.data[0].id);
      setError("");
    } catch (e) {
      setError('Failed to load conversations');
    } finally {
      setLoading(false);
    }
  }

  // API: Fetch messages for a conversation
  async function fetchMessages(convId) {
    setLoading(true);
    try {
      const res = await axios.get(`${API_BASE}/conversations/${convId}`);
      setMessages(res.data.history || []);
      setError("");
    } catch (e) {
      setError('Failed to load messages');
      setMessages([]);
    } finally {
      setLoading(false);
    }
  }

  // API: Create new conversation
  async function handleNewConversation() {
    setLoading(true);
    try {
      const res = await axios.post(`${API_BASE}/conversations`, new FormData());
      await fetchConversations();
      setSelectedConv(res.data.id);
    } catch (e) {
      setError('Failed to create conversation');
    } finally {
      setLoading(false);
    }
  }

  // API: Rename conversation
  async function handleRename() {
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append('name', modalValue);
      await axios.patch(`${API_BASE}/conversations/${modal.convId}`, fd);
      await fetchConversations();
    } catch (e) {
      setError('Failed to rename conversation');
    } finally {
      setLoading(false);
      closeModal();
    }
  }

  // API: Delete conversation
  async function handleDelete() {
    setLoading(true);
    try {
      await axios.delete(`${API_BASE}/conversations/${modal.convId}`);
      await fetchConversations();
      if (selectedConv === modal.convId) setSelectedConv(null);
    } catch (e) {
      setError('Failed to delete conversation');
    } finally {
      setLoading(false);
      closeModal();
    }
  }

  // API: Set password
  async function handlePassword() {
    setLoading(true);
    try {
      const fd = new FormData();
      fd.append('password', modalValue);
      await axios.patch(`${API_BASE}/conversations/${modal.convId}/password`, fd);
      await fetchConversations();
    } catch (e) {
      setError('Failed to set password');
    } finally {
      setLoading(false);
      closeModal();
    }
  }

  // TTS: Play/pause for a specific assistant message
  const handleTts = (msg, idx) => {
    if (!window.speechSynthesis) return;
    if (ttsPlayingId === idx) {
      window.speechSynthesis.cancel();
      setTtsPlayingId(null);
      return;
    }
    if (ttsUtteranceRef.current) window.speechSynthesis.cancel();
    const utter = new window.SpeechSynthesisUtterance(msg.content);
    ttsUtteranceRef.current = utter;
    setTtsPlayingId(idx);
    utter.onend = () => setTtsPlayingId(null);
    window.speechSynthesis.speak(utter);
  };

  // Send message: show user message instantly, show loading for AI reply
  async function handleSend(e) {
    e.preventDefault();
    if (!input.trim() || !selectedConv) return;
    setMessages((prev) => [...prev, { role: 'user', content: input }]);
    setInput('');
    setPendingReply(true);
    try {
      const fd = new FormData();
      fd.append('role', 'user');
      fd.append('content', input);
      const res = await axios.post(`${API_BASE}/conversations/${selectedConv}/messages`, fd);
      setMessages(res.data.history || []);
    } catch (e) {
      setError('Failed to send message');
    } finally {
      setPendingReply(false);
    }
  }

  // Password check API
  async function handlePasswordCheck(e) {
    e.preventDefault();
    setLoading(true);
    setPasswordError('');
    try {
      const fd = new FormData();
      fd.append('password', passwordInput);
      await axios.post(`${API_BASE}/conversations/${passwordPrompt.convId}/password`, fd);
      setPasswordPrompt(null);
      setPasswordInput('');
      setPasswordError('');
      // Now fetch messages/files
      fetchMessages(passwordPrompt.convId);
    } catch (e) {
      setPasswordError('Incorrect password');
    } finally {
      setLoading(false);
    }
  }

  // Remove password API
  async function handleRemovePassword() {
    setLoading(true);
    setRemovePwError('');
    try {
      const fd = new FormData();
      fd.append('password', removePwInput);
      // Set password to empty string to remove
      fd.append('password', '');
      await axios.patch(`${API_BASE}/conversations/${removePwModal.convId}/password`, fd);
      await fetchConversations();
      setRemovePwModal(null);
      setRemovePwInput('');
      setRemovePwError('');
    } catch (e) {
      setRemovePwError('Incorrect password');
    } finally {
      setLoading(false);
    }
  }

  // Sidebar toggle
  const handleSidebarToggle = () => setSidebarOpen((v) => !v);

  // Menu actions
  const openMenu = (id) => setMenuOpen(id);
  const closeMenu = () => setMenuOpen(null);

  // Modal actions
  const openModal = (type, convId) => {
    setModal({ type, convId });
    setModalValue('');
    closeMenu();
  };
  const closeModal = () => setModal(null);

  // Handle textarea input and Shift+Enter for new line
  const handleInputKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend(e);
    }
  };

  // Helper to check if a message is single-line (no line breaks and short)
  const isSingleLine = (text) => !text.includes('\n') && text.length < 80;

  // Determine if messages should be vertically centered (only assistant replies or pending reply)
  const shouldCenter =
    (!passwordPrompt &&
      messages.length === 1 &&
      messages[0].role === 'assistant') ||
    (messages.length === 0 && pendingReply);

  // When closing password modal after error, revert to previous conversation
  const handleClosePasswordModal = () => {
    setPasswordPrompt(null);
    setPasswordInput('');
    setPasswordError('');
    setSelectedConv(prev => {
      // If there was a previous conversation, revert to it; else, deselect
      const idx = conversations.findIndex(c => c.id === selectedConv);
      if (idx > 0) return conversations[idx - 1].id;
      if (conversations.length > 1) return conversations[1].id;
      return null;
    });
  };

  async function handleLogin(identifier, password) {
    setLoginError("");
    try {
      const fd = new FormData();
      fd.append("identifier", identifier);
      fd.append("password", password);
      await axios.post(`${API_BASE}/login`, fd);
      localStorage.setItem('chatz_logged_in', 'true');
      setAuthPage("app");
    } catch (e) {
      setLoginError(e.response?.data?.detail || "Login failed");
    }
  }

  function handleLogout() {
    localStorage.removeItem('chatz_logged_in');
    setAuthPage('login');
  }

  async function handleSignup(username, email, password, confirmPassword) {
    setSignupError("");
    if (!username || !email || !password || !confirmPassword) {
      setSignupError("All fields are required");
      return;
    }
    if (password !== confirmPassword) {
      setSignupError("Passwords do not match");
      return;
    }
    try {
      const fd = new FormData();
      fd.append("username", username);
      fd.append("email", email);
      fd.append("password", password);
      await axios.post(`${API_BASE}/register`, fd);
      setAuthPage("login");
    } catch (e) {
      setSignupError(e.response?.data?.detail || "Signup failed");
    }
  }

  if (authPage === 'login') {
    return <Login onSwitchToSignup={() => { setAuthPage('signup'); setLoginError(""); }} onLogin={handleLogin} error={loginError} />;
  }
  if (authPage === 'signup') {
    return <Signup onSwitchToLogin={() => { setAuthPage('login'); setSignupError(""); }} onSignup={handleSignup} error={signupError} />;
  }

  return (
    <>
    <div className="App">
        <button className="sidebar-toggle" onClick={handleSidebarToggle}>
          {sidebarOpen ? <span>&#10094;</span> : <span>&#9776;</span>}
        </button>
        <div className={sidebarOpen ? 'sidebar' : 'sidebar collapsed'}>
          <div className="sidebar-header" style={{ display: 'flex', alignItems: 'center', gap: 16, fontFamily: 'Caveat, cursive', fontSize: '2.6rem', fontWeight: 700, color: '#ececec', padding: '24px 0 18px 0', justifyContent: 'center' }}>
            <img src={brandingLogo} alt="logo" style={{ width: 48, height: 48, borderRadius: '50%', objectFit: 'cover', marginRight: 4, boxShadow: '0 2px 8px rgba(0,0,0,0.18)', border: '2.5px solid #232323', background: '#181818' }} />
            <span>chatz</span>
          </div>
          <button className="new-conversation-btn" onClick={handleNewConversation} disabled={loading}>+ New Conversation</button>
          <div className="conversation-list">
            {conversations.map((conv) => (
              <div
                key={conv.id}
                className={
                  'conversation-item' + (selectedConv === conv.id ? ' selected' : '')
                }
                onClick={() => setSelectedConv(conv.id)}
                style={{ position: 'relative' }}
              >
                {conv.name}
                <button
                  className="conversation-actions"
                  onClick={e => {
                    e.stopPropagation();
                    openMenu(conv.id);
                  }}
                  aria-label="Actions"
                >
                  &#8942;
                </button>
                {menuOpen === conv.id && (
                  <div className="menu" ref={menuRef}>
                    <div className="menu-item" onClick={() => openModal('rename', conv.id)}>Rename</div>
                    <div className="menu-item" onClick={() => openModal('delete', conv.id)}>Delete</div>
                    <div className="menu-item" onClick={() => openModal('password', conv.id)}>Password</div>
                    <div className="menu-item" onClick={e => { e.stopPropagation(); setSelectedConv(null); setMessages([]); closeMenu(); }}>Close</div>
                  </div>
                )}
              </div>
            ))}
          </div>
          <button
            className="account-btn"
            onClick={() => setAccountModal(true)}
            style={{
              position: 'absolute',
              left: 0,
              bottom: 0,
              width: '100%',
              background: '#232323',
              color: '#ececec',
              border: 'none',
              borderRadius: '0 0 18px 18px',
              fontSize: '1.15rem',
              fontFamily: 'Montserrat, Segoe UI, Roboto, Arial, sans-serif',
              fontWeight: 500,
              padding: '18px 0',
              boxShadow: '0 -2px 12px rgba(0,0,0,0.18)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 10,
              letterSpacing: 1,
              cursor: 'pointer',
              transition: 'background 0.18s',
              outline: 'none',
              zIndex: 2
            }}
            onMouseOver={e => (e.currentTarget.style.background = '#363636')}
            onMouseOut={e => (e.currentTarget.style.background = '#232323')}
            tabIndex={0}
          >
            <span role="img" aria-label="account" style={{ fontSize: '1.45rem', verticalAlign: 'middle' }}>👤</span>
            <span style={{ fontWeight: 600, letterSpacing: 1 }}>Account</span>
          </button>
        </div>
        <div className="chat-area">
          {selectedConv ? (
            <>
              <div className="chat-header">
                <span style={{ fontWeight: 500, fontSize: '1.2rem', color: '#ececec', fontFamily: 'Montserrat, Segoe UI, Roboto, Arial, sans-serif' }}>
                  {conversations.find((c) => c.id === selectedConv)?.name || 'Select a conversation'}
                </span>
              </div>
              <div className={`messages${shouldCenter ? ' centered' : ''}`}>
                {(!passwordPrompt) && messages.map((msg, idx) => {
                  const singleLine = msg.role === 'assistant' && isSingleLine(msg.content);
                  return (
                    <div key={idx} className={`message ${msg.role}`}
                      style={singleLine ? { display: 'flex', alignItems: 'center', position: 'relative', paddingBottom: 0 } : {}}>
                      <span style={msg.role === 'user' ? { flex: 'none', width: 'auto', display: 'inline' } : { flex: 1 }}>{msg.content}</span>
                      {msg.role === 'assistant' && (
                        singleLine ? (
                          <button
                            className={"tss-btn" + (ttsPlayingId === idx ? ' active' : '')}
                            onClick={() => handleTts(msg, idx)}
                            title={ttsPlayingId === idx ? 'Stop TTS' : 'Play TTS'}
                            style={{ position: 'static', marginLeft: 8 }}
                          >
                            {ttsPlayingId === idx ? '⏸' : '\uD83D\uDD08'}
                          </button>
                        ) : (
                          <button
                            className={"tss-btn" + (ttsPlayingId === idx ? ' active' : '')}
                            onClick={() => handleTts(msg, idx)}
                            title={ttsPlayingId === idx ? 'Stop TTS' : 'Play TTS'}
                            style={{ position: 'absolute', right: 12, bottom: 8, margin: 0 }}
                          >
                            {ttsPlayingId === idx ? '⏸' : '\uD83D\uDD08'}
                          </button>
                        )
                      )}
                    </div>
                  );
                })}
                {pendingReply && (
                  <div className="message assistant">
                    <span style={{ opacity: 0.7 }}>chatz is replying...</span>
                  </div>
                )}
                {loading && <div style={{ color: '#b0b0b0', marginTop: 12 }}>Loading...</div>}
              </div>
              <form className="input-area" onSubmit={handleSend}>
                <textarea
                  placeholder="chatz is here."
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={handleInputKeyDown}
                  disabled={loading || !selectedConv || !!passwordPrompt}
                  rows={1}
                />
                <button type="submit" disabled={loading || !selectedConv || !!passwordPrompt}>Send</button>
                <button
                  type="button"
                  className={"mic-btn" + (recognizing ? ' listening' : '')}
                  onClick={handleMic}
                  disabled={recognizing || loading || !selectedConv || !!passwordPrompt}
                  title="Speak"
                >
                  🎤
                </button>
              </form>
              {error && <div style={{ color: 'red', padding: 8 }}>{error}</div>}
            </>
          ) : (
            <div className="branding-anim" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%' }}>
              <div className="branding-logo">chatz</div>
              <img src={brandingLogo} alt="logo" className="branding-logo-img" />
              {/* Message input area for branding/empty state */}
              <form className="input-area" style={{ marginTop: 40, width: 520, maxWidth: '90vw' }} onSubmit={async (e) => {
                e.preventDefault();
                if (!input.trim()) return;
                setLoading(true);
                try {
                  // Create a new conversation
                  const convRes = await axios.post(`${API_BASE}/conversations`, new FormData());
                  const newConvId = convRes.data.id;
                  // Send the first message
                  const fd = new FormData();
                  fd.append('role', 'user');
                  fd.append('content', input);
                  await axios.post(`${API_BASE}/conversations/${newConvId}/messages`, fd);
                  setInput('');
                  // Fetch conversations and messages for the new conversation
                  await fetchConversations();
                  setSelectedConv(newConvId);
                  await fetchMessages(newConvId);
                } catch (e) {
                  setError('Failed to start a new conversation');
                } finally {
                  setLoading(false);
                }
              }}>
                <textarea
                  placeholder="chatz is here."
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={handleInputKeyDown}
                  disabled={loading}
                  rows={1}
                  style={{ resize: 'none' }}
                />
                <button type="submit" disabled={loading}>Send</button>
                <button
                  type="button"
                  className={"mic-btn" + (recognizing ? ' listening' : '')}
                  onClick={handleMic}
                  disabled={recognizing || loading}
                  title="Speak"
                >
                  🎤
                </button>
              </form>
              {error && <div style={{ color: 'red', padding: 8 }}>{error}</div>}
            </div>
          )}
          {/* Password prompt dialog */}
          {passwordPrompt && (
            <div className="modal-overlay">
              <div className="modal" onClick={e => e.stopPropagation()} style={{ position: 'relative', paddingTop: 36 }}>
                {passwordError && (
                  <button className="modal-close-btn" onClick={handleClosePasswordModal} title="Close">×</button>
                )}
                <div style={{ marginTop: 8 }}>Enter password for this conversation</div>
                <form onSubmit={handlePasswordCheck}>
                  <input
                    type="password"
                    value={passwordInput}
                    onChange={e => setPasswordInput(e.target.value)}
                    placeholder="Password"
                    disabled={loading}
                  />
                  <button type="submit" disabled={loading || !passwordInput}>OK</button>
                </form>
                {passwordError && <div style={{ color: 'red', marginTop: 8 }}>{passwordError}</div>}
              </div>
            </div>
          )}
          {/* Remove password modal */}
          {removePwModal && (
            <div className="modal-overlay" onClick={() => setRemovePwModal(null)}>
              <div className="modal" onClick={e => e.stopPropagation()}>
                <div>Enter current password to remove it</div>
                <form onSubmit={e => { e.preventDefault(); handleRemovePassword(); }}>
                  <input
                    type="password"
                    value={removePwInput}
                    onChange={e => setRemovePwInput(e.target.value)}
                    placeholder="Current password"
                    disabled={loading}
                  />
                  <button type="submit" disabled={loading || !removePwInput}>Remove Password</button>
                </form>
                {removePwError && <div style={{ color: 'red' }}>{removePwError}</div>}
              </div>
            </div>
          )}
        </div>
        {/* Account Modal */}
        {accountModal && (
          <div className="modal-overlay" onClick={() => setAccountModal(false)}>
            <div className="modal" onClick={e => e.stopPropagation()}>
              <div style={{ fontWeight: 600, fontSize: '1.2rem', marginBottom: 16 }}>Account</div>
              <button className="login-btn" style={{ width: '100%', marginBottom: 12 }} onClick={() => setAccountModal('reset')}>Reset Password</button>
              <button className="login-btn" style={{ width: '100%' }} onClick={handleLogout}>Logout</button>
            </div>
          </div>
        )}
        {/* Reset Password Modal */}
        {accountModal === 'reset' && (
          <div className="modal-overlay" onClick={() => setAccountModal(false)}>
            <div className="modal" onClick={e => e.stopPropagation()}>
              <div style={{ fontWeight: 600, fontSize: '1.2rem', marginBottom: 16 }}>Reset Password</div>
              <form>
                <input type="password" placeholder="Old Password" style={{ marginBottom: 10 }} />
                <input type="password" placeholder="New Password" style={{ marginBottom: 10 }} />
                <input type="password" placeholder="Confirm New Password" style={{ marginBottom: 16 }} />
                <button className="login-btn" style={{ width: '100%' }} type="submit">Update Password</button>
              </form>
              <button className="link-btn" style={{ marginTop: 12 }} onClick={() => setAccountModal(true)}>Back</button>
            </div>
          </div>
        )}
        {/* Modals */}
        {modal && (
          <div className="modal-overlay" onClick={closeModal}>
            <div className="modal" onClick={e => e.stopPropagation()}>
              {modal.type === 'rename' && (
                <>
                  <div>Rename Conversation</div>
                  <input
                    type="text"
                    value={modalValue}
                    onChange={e => setModalValue(e.target.value)}
                    placeholder="New name"
                  />
                  <button onClick={handleRename} disabled={loading}>Rename</button>
                </>
              )}
              {modal.type === 'delete' && (
                <>
                  <div>Are you sure you want to delete this conversation?</div>
                  <div className="modal-btn-row">
                    <button onClick={handleDelete} disabled={loading}>Yes</button>
                    <button onClick={closeModal} disabled={loading}>No</button>
                  </div>
                </>
              )}
              {modal.type === 'password' && (
                <>
                  <div>Set/Check Password</div>
                  <input
                    type="password"
                    value={modalValue}
                    onChange={e => setModalValue(e.target.value)}
                    placeholder="Password"
                  />
                  <button onClick={handlePassword} disabled={loading}>OK</button>
                </>
              )}
            </div>
          </div>
        )}
    </div>
    </>
  );
}

export default App;
