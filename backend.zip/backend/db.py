from pymongo import MongoClient
from bson.objectid import ObjectId
import os

MONGO_URI = os.environ.get("MONGO_URI") or "mongodb+srv://abbulu:abbulu.31@chatz.jda0snt.mongodb.net/?retryWrites=true&w=majority&appName=chatz"
client = MongoClient(MONGO_URI)
db = client["chatz"]
conversations = db["conversations"]
users = db["users"]

def create_conversation(data):
    return conversations.insert_one(data).inserted_id

def get_conversation(conv_id):
    return conversations.find_one({"_id": ObjectId(conv_id)})

def list_conversations():
    return list(conversations.find())

def update_conversation(conv_id, update):
    return conversations.update_one({"_id": ObjectId(conv_id)}, {"$set": update})

def delete_conversation(conv_id):
    return conversations.delete_one({"_id": ObjectId(conv_id)})

def create_user(data):
    return users.insert_one(data).inserted_id

def get_user_by_username(username):
    return users.find_one({"username": username})

def get_user_by_email(email):
    return users.find_one({"email": email})

def check_user_credentials(username, pw_hash):
    return users.find_one({"username": username, "password": pw_hash})

def check_user_credentials_username_or_email(identifier, pw_hash):
    return users.find_one({
        "$or": [
            {"username": identifier, "password": pw_hash},
            {"email": identifier, "password": pw_hash}
        ]
    }) 