from pydantic import BaseModel, Field
from typing import List, Optional

class Message(BaseModel):
    role: str  # 'user' or 'assistant'
    content: str
    timestamp: Optional[str] = None

class FileInfo(BaseModel):
    file_name: str
    file_path: str
    uploaded_at: Optional[str] = None

class Conversation(BaseModel):
    id: Optional[str] = None
    name: str = 'Untitled'
    start_time: Optional[str] = None
    history: List[Message] = []
    files: List[FileInfo] = []
    password: Optional[str] = None

class User(BaseModel):
    id: Optional[str] = None
    username: str
    email: str
    password: str  # hashed password 