import os
from huggingface_hub import InferenceClient

HF_TOKEN = os.environ.get("HF_TOKEN") or "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"
MODEL_ID = "meta-llama/Meta-Llama-3-8B-Instruct"

client = InferenceClient(provider="novita", api_key=HF_TOKEN)

def chatz_llm(messages):
    # messages: list of {role, content}
    completion = client.chat.completions.create(
        model=MODEL_ID,
        messages=messages,
    )
    return completion.choices[0].message.content 