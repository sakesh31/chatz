from fastapi import FastAPI, HTTPException, UploadFile, File, Form, Body, status
from fastapi.middleware.cors import CORSMiddleware
from typing import List
from models import Conversation, Message, FileInfo, User
from db import create_conversation, get_conversation, list_conversations, update_conversation, delete_conversation, create_user, get_user_by_username, get_user_by_email, check_user_credentials, check_user_credentials_username_or_email
from bson.objectid import ObjectId
import datetime
from chatz_llm import chatz_llm
import os
import hashlib

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

UPLOAD_DIR = os.path.join(os.path.dirname(__file__), 'uploads')
os.makedirs(UPLOAD_DIR, exist_ok=True)

@app.get("/")
def root():
    return {"message": "Welcome to chatz backend!"}

@app.get("/health")
def health():
    return {"status": "ok"}

def convert_history(history):
    # Accepts a list of either {'role', 'content'} or {'question', 'answer'}
    new_history = []
    for item in history:
        if 'role' in item and 'content' in item:
            new_history.append(item)
        elif 'question' in item and 'answer' in item:
            new_history.append({'role': 'user', 'content': item['question']})
            new_history.append({'role': 'assistant', 'content': item['answer']})
    return new_history

@app.get("/conversations", response_model=List[Conversation])
def get_convs():
    return [Conversation(id=str(c["_id"]), name=c.get("name", "Untitled"), start_time=c.get("start_time"), history=convert_history(c.get("history", [])), files=c.get("files", []), password=c.get("password")) for c in list_conversations()]

@app.post("/conversations", response_model=Conversation)
def create_conv(name: str = Form("Untitled")):
    conv = {
        "name": name,
        "start_time": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        "history": [],
        "files": [],
        "password": None
    }
    conv_id = create_conversation(conv)
    conv["_id"] = conv_id
    return Conversation(id=str(conv_id), **conv)

@app.get("/conversations/{conv_id}", response_model=Conversation)
def get_conv(conv_id: str):
    c = get_conversation(conv_id)
    if not c:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return Conversation(id=str(c["_id"]), name=c.get("name", "Untitled"), start_time=c.get("start_time"), history=convert_history(c.get("history", [])), files=c.get("files", []), password=c.get("password"))

@app.patch("/conversations/{conv_id}")
def rename_conv(conv_id: str, name: str = Form(...)):
    update_conversation(conv_id, {"name": name})
    return {"status": "ok"}

@app.delete("/conversations/{conv_id}")
def delete_conv(conv_id: str):
    delete_conversation(conv_id)
    return {"status": "deleted"}

@app.post("/conversations/{conv_id}/messages")
def chat(conv_id: str, role: str = Form(...), content: str = Form(...)):
    c = get_conversation(conv_id)
    if not c:
        raise HTTPException(status_code=404, detail="Conversation not found")
    # Add user message to history
    history = c.get("history", [])
    history.append({"role": role, "content": content})
    assistant_reply = None
    # Use LLM for assistant reply only if user message
    if role == "user":
        assistant_reply = chatz_llm(history)
        history.append({"role": "assistant", "content": assistant_reply})
    update_conversation(conv_id, {"history": history})
    return {"reply": assistant_reply, "history": history}

@app.post("/conversations/{conv_id}/file")
def upload_file(conv_id: str, file: UploadFile = File(...)):
    c = get_conversation(conv_id)
    if not c:
        raise HTTPException(status_code=404, detail="Conversation not found")
    file_location = os.path.join(UPLOAD_DIR, file.filename)
    with open(file_location, "wb") as f:
        f.write(file.file.read())
    file_info = {
        "file_name": file.filename,
        "file_path": file_location,
        "uploaded_at": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    files = c.get("files", [])
    files.append(file_info)
    update_conversation(conv_id, {"files": files})
    return {"status": "uploaded", "file": file_info}

@app.patch("/conversations/{conv_id}/password")
def set_password(conv_id: str, password: str = Form(...)):
    if len(password) < 4:
        raise HTTPException(status_code=400, detail="Password must be at least 4 characters.")
    pw_hash = hashlib.sha256(password.encode()).hexdigest()
    update_conversation(conv_id, {"password": pw_hash})
    return {"status": "password set"}

@app.post("/conversations/{conv_id}/password")
def check_password(conv_id: str, password: str = Form(...)):
    c = get_conversation(conv_id)
    if not c or not c.get("password"):
        raise HTTPException(status_code=404, detail="No password set for this conversation.")
    pw_hash = hashlib.sha256(password.encode()).hexdigest()
    if pw_hash == c["password"]:
        return {"status": "ok"}
    else:
        raise HTTPException(status_code=401, detail="Incorrect password.")

@app.post("/register")
def register(username: str = Form(...), email: str = Form(...), password: str = Form(...)):
    if get_user_by_username(username):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username already exists")
    if get_user_by_email(email):
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already exists")
    pw_hash = hashlib.sha256(password.encode()).hexdigest()
    user = {"username": username, "email": email, "password": pw_hash}
    user_id = create_user(user)
    return {"status": "ok", "user_id": str(user_id)}

@app.post("/login")
def login(identifier: str = Form(...), password: str = Form(...)):
    pw_hash = hashlib.sha256(password.encode()).hexdigest()
    user = check_user_credentials_username_or_email(identifier, pw_hash)
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid username/email or password")
    return {"status": "ok", "username": user["username"]} 